//
//  Diario.swift
//  EquAI
//
//  Created by CEDAM 12 on 07/03/24.
//

import SwiftUI

struct Diario: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    Diario()
}
