//
//  computer_nerdysApp.swift
//  computer nerdys
//
//  Created by CEDAM03 on 07/03/24.
//

import SwiftUI

@main
struct computer_nerdysApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
