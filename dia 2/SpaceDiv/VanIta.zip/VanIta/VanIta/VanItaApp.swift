//
//  VanItaApp.swift
//  VanIta
//
//  Created by CEDAM17 on 07/03/24.
//

import SwiftUI

@main
struct VanItaApp: App {
    var body: some Scene {
        WindowGroup {
            Home()
        }
    }
}
