//
//  Bienvenida.swift
//  VanIta
//
//  Created by CEDAM17 on 07/03/24.
//

import SwiftUI

struct Bienvenida: View {
    var body: some View {
        ZStack{
            Image("vanita")
                .resizable()
                .ignoresSafeArea(.all)
            VStack {
        
            }
            .padding()
        }
            .ignoresSafeArea()
    }
}


#Preview {
    Bienvenida()
}
