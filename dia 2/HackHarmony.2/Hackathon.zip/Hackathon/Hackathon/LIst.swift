//
//  LIst.swift
//  Hackathon
//
//  Created by CEDAM 13 on 08/03/24.
//

import Foundation

struct Divice
{
    let title: String
    let imageName: String
}

let ConocimientosBasicos = [
    Divice(title: "Primaria", imageName: "primaria"),
    Divice(title: "Secundaria", imageName: "secundaria")
]

let ConocimientosTecnicos = [
    Divice(title: "Carpinteria", imageName: "carpinteria"),
    Divice(title: "Mecanica", imageName: "mecanica")

]
