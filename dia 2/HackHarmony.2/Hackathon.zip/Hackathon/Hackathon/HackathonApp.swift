//
//  HackathonApp.swift
//  Hackathon
//
//  Created by CEDAM 13 on 07/03/24.
//

import SwiftUI

@main
struct HackathonApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
