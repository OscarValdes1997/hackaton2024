//
//  Home.swift
//  Hackathon
//
//  Created by CEDAM 13 on 08/03/24.
//

import Foundation
import SwiftUI

func Home() -> some View {
    return NavigationView {
        VStack {
            // Todo lo que va en la pantalla de inicio
            
        }
    }
    .overlay(
        SliderView()
    )
}
