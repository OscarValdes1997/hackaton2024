//
//  EquAIApp.swift
//  EquAI
//
//  Created by CEDAM 12 on 07/03/24.
//

import SwiftUI

@main
struct EquAIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
