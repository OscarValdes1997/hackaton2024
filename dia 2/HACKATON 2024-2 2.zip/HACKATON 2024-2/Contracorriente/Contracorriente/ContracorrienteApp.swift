//
//  ContracorrienteApp.swift
//  Contracorriente
//
//  Created by CEDAM35 on 07/03/24.
//

import SwiftUI

@main
struct ContracorrienteApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
