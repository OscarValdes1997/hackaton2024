//
//  Idioma.swift
//  Contracorriente
//
//  Created by CEDAM35 on 07/03/24.
//

import Foundation
import SwiftUI

struct idioma {
    let id:Int
    var nombre:String
    var avatar:Image
}
