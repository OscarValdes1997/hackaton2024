//
//  SwiftUIView.swift
//  busquedatrabajo
//
//  Created by CEDAM29 on 08/03/24.
//

import SwiftUI

struct SwiftUIView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    SwiftUIView()
}
