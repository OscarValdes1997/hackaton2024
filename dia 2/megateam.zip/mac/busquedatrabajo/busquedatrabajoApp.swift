//
//  busquedatrabajoApp.swift
//  busquedatrabajo
//
//  Created by CEDAM29 on 08/03/24.
//

import SwiftUI

@main
struct busquedatrabajoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
