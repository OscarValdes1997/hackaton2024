//
//  curso6.swift
//  educacion2
//
//  Created by CEDAM16 on 07/03/24.
//

import SwiftUI

struct curso6: View {
    var body: some View 
    {
        VStack
        {
            Image("quimica")
            VStack
            {
                ZStack
                {
                    Rectangle()
                        .foregroundColor(.black)
                    VStack(spacing: 20)
                    {
                        Text("Quimica Organica")
                            .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                            .foregroundStyle(.white)
                        Text("Curso impartido por el Dr. Alvaro Hernandez")
                            .font(.headline)
                            .font(.callout)
                            .foregroundStyle(.white)
                        Text("Duracion 2 hrs. L-M-V ")
                            .font(.headline)
                            .font(.callout)
                            .foregroundStyle(.white)
                        Text("Comienza el 21 de Abril a las 2:00 pm")
                            .font(.headline)
                            .font(.callout)
                            .foregroundStyle(.white)
                        Text("Ubicación del taller: Edayo")
                            .font(.headline)
                            .font(.callout)
                            .foregroundStyle(.white)
                        Image("UNi")
                            .resizable()
                            .scaledToFill()
                            .frame(width: 100, height: 100)
                            .cornerRadius(20)
                            .clipped()
                            .clipShape(Rectangle())
                    
                        
                    }
                }
                
            }
            
        }
    }
}

#Preview {
    curso6()
}
