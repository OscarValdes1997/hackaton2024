//
//  curso3.swift
//  educacion2
//
//  Created by CEDAM16 on 07/03/24.
//

import SwiftUI

struct curso3: View {
    var body: some View 
    {
        VStack
        {
            Image("analisis")
            VStack
            {
                ZStack
                {
                    Rectangle()
                        .foregroundColor(.white)
                    VStack(spacing:20)
                    {
                        Text("Análisis Real")
                            
                            .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                            .foregroundStyle(.black)

                        Text("Curso impartido por el Dr. Ernesto Aguilar")
                            .font(.headline)
                            .font(.callout)
                            .foregroundStyle(.black)
                        Text("Duracion 2 hrs. L-M-V ")
                            .font(.headline)
                            .font(.callout)
                            .foregroundStyle(.black)
                        Text("Comienza el 22 de marzo a las 2:00 pm")
                            .font(.headline)
                            .font(.callout)
                            .foregroundStyle(.black)
                        Text("Ubicación del taller: Edayo")
                            .font(.headline)
                            .font(.callout)
                            .foregroundStyle(.black)
                        Image("UNi")
                            .resizable()
                            .scaledToFill()
                            .frame(width: 100, height: 100)
                            .cornerRadius(20)
                            .clipped()
                            .clipShape(Rectangle())
                    
                        
                    }
                }
                
            }
            
        }
    }
}

#Preview {
    curso3()
}
