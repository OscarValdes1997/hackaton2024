//
//  Card2.swift
//  educacion2
//
//  Created by CEDAM16 on 08/03/24.
//

import SwiftUI

struct Card2: View {
    @Binding var isShowingD:Bool
    var animation1:Namespace.ID
    var body: some View
    {
        VStack
        {
            //Image("rostro")
            Text("Neurociencia")
                .font(.callout)
            Image("redes")
                .resizable()
                .matchedGeometryEffect(id: "image", in: animation1)
                .frame(width: 200, height: 200)
                .cornerRadius(20)
                .shadow(radius: 5)
                .transition(.scale(scale: 1))
            Button("Ver detalles")
            {
                withAnimation{
                    isShowingD=true
                }
            }
                
        }
        
    }
}

