//
//  portada2.swift
//  educacion2
//
//  Created by CEDAM16 on 08/03/24.
//

import SwiftUI

struct portada2: View
{
    
    var body: some View
    {
        ZStack
        {
            
            
        }
    }
        
}

#Preview {
    portada()
}
