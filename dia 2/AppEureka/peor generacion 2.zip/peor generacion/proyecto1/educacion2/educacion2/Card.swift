//
//  Card.swift
//  educacion2
//
//  Created by CEDAM16 on 08/03/24.
//

import SwiftUI

struct Card: View {
    @Binding var isShowingDetail:Bool
    var animation:Namespace.ID
    var body: some View 
    {
        VStack
        {
            //Image("rostro")
            Text("Reposteria")
                .font(.callout)
            Image("reposteria")
                .resizable()
                .matchedGeometryEffect(id: "image", in: animation)
                .frame(width: 200, height: 200)
                .cornerRadius(20)
                .shadow(radius: 5)
                .transition(.scale(scale: 1))
            Button("Ver detalles")
            {
                withAnimation{
                    isShowingDetail=true
                }
            }
                
        }
        
    }
}

