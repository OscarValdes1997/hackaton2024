//
//  card1.swift
//  educacion2
//
//  Created by CEDAM16 on 08/03/24.
//

import SwiftUI

struct card1: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    card1()
}
