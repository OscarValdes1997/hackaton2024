//
//  portada.swift
//  educacion2
//
//  Created by CEDAM16 on 08/03/24.
//

import SwiftUI

struct portada: View 
{
    @State private var isShowingDetail = false
    @Namespace var animation
    
    var body: some View
    {
        NavigationStack
        {
            ScrollView
            {
                VStack
                {
                    
                        ZStack {
                            if isShowingDetail
                            {
                                        CardDetail(
                                            isShowingDetail: $isShowingDetail,
                                            animation: animation
                                        )
                            } else {
                                Card(
                                            isShowingDetail: $isShowingDetail,
                                            animation: animation
                                    )
                                
                                .transition(.scale(scale: 1))
                                }
                            }
   
                }
       
                
            }
            
            
           
        
        }
            
    }
        
}
#Preview {
    portada()
}


