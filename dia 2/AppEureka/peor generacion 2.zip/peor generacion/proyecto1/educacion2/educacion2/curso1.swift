//
//  curso1.swift
//  educacion2
//
//  Created by CEDAM16 on 07/03/24.
//

import SwiftUI

struct curso1: View 
{
    var body: some View 
    {
        VStack
        {
            Image("arq")
            VStack
            {
                ZStack
                {
                    Rectangle()
                        .foregroundColor(.white)
                    VStack(spacing: 20)
                    {
                        Text("Dibujo Aquitectonico")
                            .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                            .foregroundStyle(.black)
                            
                        Text("Curso impartido por el Arq. Angel Perez")
                            .font(.headline)
                            .font(.callout)
                            .foregroundStyle(.black)
                        Text("Duracion 2 hrs. L-M-V ")
                            .font(.headline)
                            .font(.callout)
                            .foregroundStyle(.black)
                        Text("Comienza el 12 de marzo a las 3:00 pm")
                            .font(.headline)
                            .font(.callout)
                            .foregroundStyle(.black)
                        Text("Ubicación del taller: Edayo")
                            .font(.headline)
                            .font(.callout)
                            .foregroundStyle(.black)
                        Image("cia")
                            .resizable()
                            .scaledToFill()
                            .frame(width: 100, height: 100)
                            .cornerRadius(20)
                            .clipped()
                            .clipShape(Rectangle())
                        
                    
                        
                    }
                }
                
            }
            
        }
    }
}

#Preview {
    curso1()
}
