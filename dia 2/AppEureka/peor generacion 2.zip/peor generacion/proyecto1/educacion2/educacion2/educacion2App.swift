//
//  educacion2App.swift
//  educacion2
//
//  Created by CEDAM16 on 07/03/24.
//

import SwiftUI

@main
struct educacion2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
