//
//  Card3.swift
//  educacion2
//
//  Created by CEDAM16 on 08/03/24.
//

import SwiftUI

struct Card3: View {
    @Binding var isShowingD1:Bool
    var animation3:Namespace.ID
    var body: some View
    {
        VStack
        {
            //Image("rostro")
            Text("Modelaje en 3D con Blender")
                .font(.callout)
            Image("3d")
                .resizable()
                .matchedGeometryEffect(id: "image", in: animation3)
                .frame(width: 200, height: 200)
                .cornerRadius(20)
                .shadow(radius: 5)
                .transition(.scale(scale: 1))
            Button("Ver detalles")
            {
                withAnimation{
                    isShowingD1=true
                }
            }
                
        }
        
    }
}


