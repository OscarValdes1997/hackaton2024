//
//  ventana1.swift
//  educacion2
//
//  Created by CEDAM16 on 07/03/24.
//

import SwiftUI

struct ventana1: View

{
    @State private var isShowingDetail = false
    @State private var isShowingD = false
    @State private var isShowingD1 = false
    
    @Namespace var animation
    @Namespace var animation1
    @Namespace var animation3
    var body: some View
    {
        NavigationStack
        {
            VStack
            {
                HStack
                {
                    VStack
                    {
                        Image("rostro")
                            .resizable()
                            .scaledToFill()
                            .frame(width: 100, height: 100)
                            .clipped()
                            .clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
                        NavigationLink
                        {
                            perfil()
                        }label:{
                            Text("Perfil")
                                .frame(width: 50,height: 50)
                        }
                    }
                }
            }
            Text("Curso Recomendados")
                .font(.callout)
            ScrollView(.horizontal)
            {
                HStack
                {
                    VStack
                    {
                        NavigationLink{
                            curso1()
                        }label:{
                            Image("arq")
                                .resizable()
                                .scaledToFill()
                                .frame(width: 100, height: 100)
                                .cornerRadius(20)
                                .clipped()
                                .clipShape(Rectangle())
                            
                            
                        }
                        Text("Dibujo Arquitectonico")
                        
                    }

                    VStack
                    {
                        NavigationLink{
                            curso3()
                        }label:{
                            Image("analisis")
                                .resizable()
                                .scaledToFill()
                                .frame(width: 100, height: 100)
                                .cornerRadius(20)
                                .clipped()
                                .clipShape(Rectangle())
                            
                        }
                        Text("Análisis Real")
                        
                    }
                    VStack
                    {
                        NavigationLink{
                            curso4()
                        }label:{
                            Image("diseño")
                                .resizable()
                                .scaledToFill()
                                .frame(width: 100, height: 100)
                                .cornerRadius(20)
                                .clipped()
                                .clipShape(Rectangle())
                            
                        }
                        Text("Diseño")
                        
                    }
                    VStack
                    {
                        NavigationLink{
                            curso5()
                        }label:{
                            Image("biologia")
                                .resizable()
                                .scaledToFill()
                                .frame(width: 100, height: 100)
                                .cornerRadius(20)
                                .clipped()
                                .clipShape(Rectangle())
                            
                        }
                        Text("Biologia I")
                        
                    }
                    VStack
                    {
                        NavigationLink{
                            curso6()
                        }label:{
                            Image("quimica")
                                .resizable()
                                .scaledToFill()
                                .frame(width: 100, height: 100)
                                .cornerRadius(20)
                                .clipped()
                                .clipShape(Rectangle())
                            
                        }
                        Text("Quimica Organica")
                    }
                    
                }
            }
            .padding(.top,30)
            
            
            
            ScrollView(.vertical)
            {
                VStack(spacing: 20){
                HStack
                                    {
                    VStack
                    {
                        ZStack {
                            if isShowingDetail
                            {
                                CardDetail(
                                    isShowingDetail: $isShowingDetail,
                                    animation: animation
                                )
                            } else {
                                Card(
                                    isShowingDetail: $isShowingDetail,
                                    animation: animation
                                    
                                )
                            }
                        }
                        
                    }
                }
                    HStack
                                        {
                        VStack
                        {
                            ZStack {
                                if isShowingD
                                {
                                    CardDetail2(
                                        isShowingD: $isShowingD,
                                        animation1: animation1
                                    )
                                } else {
                                    Card2(
                                        isShowingD: $isShowingD,
                                        animation1: animation1
                                        
                                    )
                                }
                            }
                            
                        }
                    }
                    HStack
                                        {
                        VStack
                        {
                            ZStack {
                                if isShowingD1
                                {
                                    CardDetail3(
                                        isShowingD1: $isShowingD1,
                                        animation3: animation3
                                    )
                                } else {
                                    Card3(
                                        isShowingD1: $isShowingD1,
                                        animation3: animation3
                                        
                                    )
                                }
                            }
                            
                        }
                    }
                 
                }
            }
            .padding(.top,50)
            
        
        }
        
    }
}

#Preview {
    ventana1()
}

