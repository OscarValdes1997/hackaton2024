//
//  inicio.swift
//  educacion2
//
//  Created by CEDAM16 on 08/03/24.
//

import SwiftUI

struct inicio: View 
{
    var body: some View 
    {
        NavigationStack
        {
            ZStack
            {
                VStack
                {
                    NavigationLink{
                        ventana1()
                    }label: {
                        VStack(spacing: 1)
                        {
                            Image("eurekal")
                                .resizable()
                                .frame(width: 200, height: 200)
                            Image("eurekale")
                                .resizable()
                                .frame(width: 150, height: 150)
      
                        }
                       
                    }
                    
                }
            
            }
            
        }
        
    }
}

#Preview {
    inicio()
}
