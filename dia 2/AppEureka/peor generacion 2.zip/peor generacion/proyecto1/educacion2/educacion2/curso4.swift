//
//  curso4.swift
//  educacion2
//
//  Created by CEDAM16 on 07/03/24.
//

import SwiftUI

struct curso4: View {
    var body: some View 
    {
        VStack
        {
            Image("diseño")
            VStack
            {
                ZStack
                {
                    Rectangle()
                        .foregroundColor(.black)
                    VStack(spacing: 20)
                    {
                        Text("Diseño de Autos")
                            .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                            .foregroundStyle(.white)
                        Text("Curso impartido por el Lic. Armando Roa")
                            .font(.headline)
                            .font(.callout)
                            .foregroundStyle(.white)
                        Text("Duracion 2 hrs. L-M-V ")
                            .font(.headline)
                            .font(.callout)
                            .foregroundStyle(.white)
                        Text("Comienza el 30 de mayo a las 6:00 pm")
                            .font(.headline)
                            .font(.callout)
                            .foregroundStyle(.white)
                        Text("Ubicación del taller: Edayo")
                            .font(.headline)
                            .font(.callout)
                            .foregroundStyle(.white)
                        Image("UNi")
                            .resizable()
                            .scaledToFill()
                            .frame(width: 100, height: 100)
                            .cornerRadius(20)
                            .clipped()
                            .clipShape(Rectangle())
                    
                        
                    }
                }
                
            }
            
        }
    }
}

#Preview {
    curso4()
}
