//
//  CardDetail3.swift
//  educacion2
//
//  Created by CEDAM16 on 08/03/24.
//

import SwiftUI

struct CardDetail3: View {
    @Binding var isShowingD1:Bool
    var animation3:Namespace.ID
    var body: some View {
        VStack
        {
            
            Text("Curso impartido por Lic. Brandon Vega ,    Duracion 2 hrs. de L-M-V")
            //.padding()
            .frame(width: 300, height: 300)
            .background(Color.white)
            .cornerRadius(20)
            .shadow(radius: 5)
            .matchedGeometryEffect(id: "cardDatail", in: animation3)
            .transition(.scale(scale: 1))
            Button("Cerrar")
            {
                //Text("h")
                withAnimation{
                    isShowingD1=false
                }
            }
        }
    }
}


