//
//  CardDetail.swift
//  educacion2
//
//  Created by CEDAM16 on 08/03/24.
//

import SwiftUI

struct CardDetail: View {
    @Binding var isShowingDetail:Bool
    var animation:Namespace.ID
    var body: some View {
        VStack
        {
            Text("Curso impartido por Luisa Jimenez, Duracion 2 hrs. de L-M-V")
            
            //.padding()
            .frame(width: 300, height: 300)
            .background(Color.white)
            .cornerRadius(20)
            .shadow(radius: 5)
            .matchedGeometryEffect(id: "cardDatail", in: animation)
            .transition(.scale(scale: 1))
            Button("Cerrar")
            {
                //Text("h")
                withAnimation{
                    isShowingDetail=false
                }
            }
        }
    }
}

