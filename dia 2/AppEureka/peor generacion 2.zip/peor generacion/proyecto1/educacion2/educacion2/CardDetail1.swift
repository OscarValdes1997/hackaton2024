//
//  CardDetail1.swift
//  educacion2
//
//  Created by CEDAM16 on 08/03/24.
//

import SwiftUI

struct CardDetail1: View {
    @Binding var isShowingDetail:Bool
    var animation:Namespace.ID
    var body: some View {
        VStack
        {
            Text("h")
            //.padding()
            .frame(width: 200, height: 200)
            .background(Color.white)
            .cornerRadius(20)
            .shadow(radius: 5)
            .matchedGeometryEffect(id: "cardDatail", in: animation)
            
            Button("Cerrar")
            {
                //Text("h")
                withAnimation{
                    isShowingDetail=false
                }
            }
        }
    }
}


