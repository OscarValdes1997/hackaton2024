//
//  ingresar.swift
//  educacion2
//
//  Created by CEDAM16 on 08/03/24.
//

import SwiftUI

struct ingresar: View 
{
    var body: some View 
    {
        NavigationStack
        {
            ZStack
            {
                
                Circle()
                    .frame(width: 150)
                    
                
            }
            
        }
        
    }
}

#Preview {
    ingresar()
}
