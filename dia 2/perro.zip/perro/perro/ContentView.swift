//
//  ContentView.swift
//  perro
//
//  Created by Oscar on 06/03/24.
//

import SwiftUI

struct ContentView: View {
    @State private var texto1: String = ""
    @State private var texto2: String = ""
    var body: some View {
        ZStack{
            Color.blue.opacity(0.5)
            Image("foto1")
                .resizable()//dimenciona nuestra imagen
                .frame(width: 200, height: 200)//tamaño
                .cornerRadius(8.0)//bordes
                .offset(y:-250)//subir,bajar, posición
                .shadow(color: .white, radius: 10)
            Text("La Combinada")
                .font(.title.bold())
                .offset(y:-100)
                .foregroundColor(.white)
            
            Image("foto2")
                .resizable()//dimenciona nuestra imagen
                .frame(width: 50, height: 50)//tamaño
                .cornerRadius(8.0)//bordes
                .offset(x:-130, y:-34)
            Image("foto3")
                .resizable()//dimenciona nuestra imagen
                .frame(width: 50, height: 50)//tamaño
                .cornerRadius(8.0)//bordes
                .offset(x:-130, y:35)
            VStack{
                TextField("Usuario", text: $texto1)
                    .padding()
                    .background(Color.white)
                    .cornerRadius(8.0)
                    .padding(.horizontal)
                    .frame(width: 200)
                TextField("Contraseña", text: $texto2)
                    .padding()
                    .background(Color.white)
                    .cornerRadius(8.0)
                    .padding(.horizontal)
                    .frame(width: 200)
                    
            }
            
        }
        
        .ignoresSafeArea()
        
    }
}

#Preview {
    ContentView()
}
