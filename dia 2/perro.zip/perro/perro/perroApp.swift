//
//  perroApp.swift
//  perro
//
//  Created by Oscar on 06/03/24.
//

import SwiftUI

@main
struct perroApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
