//
//  ContentView.swift
//  Contracorriente
//
//  Created by CEDAM35 on 07/03/24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        inicio()
    }
}

#Preview {
    ContentView()
}
