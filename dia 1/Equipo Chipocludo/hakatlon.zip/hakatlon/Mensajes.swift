//
//  Mensajes.swift
//  hakatlon
//
//  Created by CEDAM23 on 07/03/24.
//

import SwiftUI

struct Mensajes: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
        Spacer()
    }
}

#Preview {
    Mensajes()
}
