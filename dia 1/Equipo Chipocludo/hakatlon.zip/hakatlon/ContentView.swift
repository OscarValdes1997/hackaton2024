//
//  ContentView.swift
//  hakatlon
//
//  Created by CEDAM23 on 07/03/24.
//

import SwiftUI

struct ContentView: View {
    
    enum Tab {
      case home, foro, mensajes, notificaciones,perfil
     }
    
    @State private var selectedTab: Tab = .home
    
    var body: some View {
        
        TabView(selection: $selectedTab){
            Home()
                .tabItem { Image(systemName:"house" ) }
                .tag(Tab.home)
            Foro()
                .tabItem { Image(systemName: "bubble.left.and.text.bubble.right") }
                .tag(Tab.foro)
            Mensajes()
                .tabItem { Image(systemName: "message") }
                .tag(Tab.mensajes)
            Notificaciones()
                .tabItem { Image(systemName: "bell") }
                .tag(Tab.notificaciones)
            Perfil()
                .tabItem { Image(systemName: "person") }
                .tag(Tab.perfil)
                
        }
        
            
        }
        }
        
            
        
        
    

    
#Preview {
    ContentView()
}
