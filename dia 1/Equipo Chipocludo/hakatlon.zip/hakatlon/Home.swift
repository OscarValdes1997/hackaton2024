//
//  Home.swift
//  hakatlon
//
//  Created by CEDAM23 on 07/03/24.
//

import SwiftUI

struct Home: View {
    var body: some View {
        VStack(spacing: 40){
            
            HStack(spacing: -10){
                Image("perfil")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 200,height: 100)
                VStack(spacing: 10){
                    
                    Text("Hola estoy buscando becas para estudiantes jajaja")
                    HStack(spacing: 30){
                        Image(systemName: "heart")
                            .foregroundColor(.red)
                        Image(systemName: "arrowshape.turn.up.right")
                            .foregroundColor(/*@START_MENU_TOKEN@*/.blue/*@END_MENU_TOKEN@*/)
                        Image(systemName: "bubble")
                            .foregroundColor(.green)
                    }
                }
                Spacer()
            }
            HStack(spacing: -10){
                Image("perfil2")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 200,height: 100)
                VStack(spacing: 10){
                    
                    Text("Hola estoy buscando becas para estudiantes jajaja")
                    HStack(spacing: 30){
                        Image(systemName: "heart")
                            .foregroundColor(.red)
                        Image(systemName: "arrowshape.turn.up.right")
                            .foregroundColor(/*@START_MENU_TOKEN@*/.blue/*@END_MENU_TOKEN@*/)
                        Image(systemName: "bubble")
                            .foregroundColor(.green)
                    }
                }
                Spacer()
            }
            
            
        }
        Spacer()
    }
}

#Preview {
    Home()
}
