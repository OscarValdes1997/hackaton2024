//
//  hakatlonApp.swift
//  hakatlon
//
//  Created by CEDAM23 on 07/03/24.
//

import SwiftUI

@main
struct hakatlonApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
