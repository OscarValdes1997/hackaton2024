//
//  ventana3.swift
//  ComputerNerdys
//
//  Created by CEDAM02 on 07/03/24.
//

import SwiftUI

struct ventana3: View {
    var body: some View {
        NavigationStack{
            VStack{
                Text("¿Qué quieres hacer?").font(.largeTitle)
                NavigationLink{
                    //Reporte()
                } label:{
                    Text("Levantar reporte")
                        .foregroundColor(.black)
                        .frame(width: 250, height: 60)
                        .background(Color.gray)
                        .cornerRadius(100)
                }
                .padding()
                NavigationLink{
                    Orientacion()
                } label:{
                    Text("Buscar orientación")
                        .foregroundColor(.black)
                        .frame(width: 250, height: 60)
                        .background(Color.gray)
                        .cornerRadius(100)
                }
                .padding()
                NavigationLink{
                    //ventana()
                } label:{
                    Text("Informar de alguna problematica externa")
                        .foregroundColor(.black)
                        .frame(width: 250, height: 60)
                        .background(Color.gray)
                        .cornerRadius(100)
                }
                .padding()
                NavigationLink{
                    //ventana()
                } label:{
                    Text("Noticias")
                        .foregroundColor(.black)
                        .frame(width: 250, height: 60)
                        .background(Color.gray)
                        .cornerRadius(100)
                }
                .padding()
            }
        }
        
    }
}

#Preview {
    ventana3()
}
