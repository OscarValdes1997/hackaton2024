//
//  Orientacion.swift
//  ComputerNerdys
//
//  Created by CEDAM02 on 07/03/24.
//

import SwiftUI

   
    
struct Orientacion: View {
    @State private var selectedCorreo = "Dark"
    let correo = ["correo1", "correo2", "correo3"]
    
    @State private var selectedTelefono = "Telefonos"
    let telefono = ["telefono1", "telefono2", "telefono3"]
    
    @State private var selectedRedes = "Telefonos"
    let redes = ["Facebook", "Instagram", "Twitter"]
    
    var body: some View {
        NavigationStack {
            Text("Servicios de apoyo")
            Form {
                    Picker("Correos Electronicos", selection: $selectedCorreo) {
                            ForEach(correo, id: \.self) {
                                    Text($0)
                                }
                            }
                            .pickerStyle(.navigationLink)
                            
                Picker("Telefonos", selection: $selectedTelefono) {
                        ForEach(telefono, id: \.self) {
                                Text($0)
                            }
                        }
                        .pickerStyle(.navigationLink)
                
                Picker("Redes Sociales ", selection: $selectedRedes) {
                        ForEach(redes, id: \.self) {
                                Text($0)
                            }
                        }
                        .pickerStyle(.navigationLink)

                        }
                        .navigationTitle("Buscar Orientación")
                        
            
                }
        
        }
    }

#Preview {
    Orientacion()
}
