//
//  ventana2.swift
//  ComputerNerdys
//
//  Created by CEDAM02 on 07/03/24.
//

import SwiftUI
import UIKit

struct ventana2: View {
    @State var choiceMade = "Estados"
    var body: some View {
        NavigationStack{
            VStack{
                
                Text("¿De dónde eres?").font(.largeTitle)
                
                
                Menu{
                    ScrollView{
                        Button(action: {
                            choiceMade = "Aguascalientes"
                        }, label:{
                            Text("Aguascalientes")
                        })
                        Button(action: {
                            choiceMade = "Baja California"
                        }, label:{
                            Text("Baja California")
                        })
                        Button(action: {
                            choiceMade = "Baja California Sur"
                        }, label:{
                            Text("Baja California Sur")
                        })
                        Button(action: {
                            choiceMade = "Campeche"
                        }, label:{
                            Text("Campeche")
                        })
                        Button(action: {
                            choiceMade = "Chiapas"
                        }, label:{
                            Text("Chiapas")
                        })
                        Button(action: {
                            choiceMade = "Chihuahua"
                        }, label:{
                            Text("Chihuahua")
                        })
                        Button(action: {
                            choiceMade = "Coahuila"
                        }, label:{
                            Text("Coahuila")
                        })
                        Button(action: {
                            choiceMade = "Colima"
                        }, label:{
                            Text("Colima")
                        })
                        Button(action: {
                            choiceMade = "Ciudad de México"
                        }, label:{
                            Text("Ciudad de México")
                        })
                        Button(action: {
                            choiceMade = "Durango"
                        }, label:{
                            Text("Durango")
                        })
                        Button(action: {
                            choiceMade = "Estado de México"
                        }, label:{
                            Text("Estado de México")
                        })
                        Button(action: {
                            choiceMade = "Guanajuato"
                        }, label:{
                            Text("Guanajuato")
                        })
                        Button(action: {
                            choiceMade = "Guerrero"
                        }, label:{
                            Text("Guerrero")
                        })
                        Button(action: {
                            choiceMade = "Hidalgo"
                        }, label:{
                            Text("Hidalgo")
                        })
                        Button(action: {
                            choiceMade = "Jalisco"
                        }, label:{
                            Text("Jalisco")
                        })
                        Button(action: {
                            choiceMade = "Michoacán"
                        }, label:{
                            Text("Michoacán")
                        })
                        Button(action: {
                            choiceMade = "Morelos"
                        }, label:{
                            Text("Morelos")
                        })
                        Button(action: {
                            choiceMade = "Nayarit"
                        }, label:{
                            Text("Nayarit")
                        })
                        Button(action: {
                            choiceMade = "Nuevo León"
                        }, label:{
                            Text("Nuevo León")
                        })
                    }
                    
                }label:{
                    Label(
                        title:{Text("\(choiceMade)")
                                .foregroundColor(.white)
                                .frame(width: 150, height: 50)
                                .background(.gray)
                            .cornerRadius(5)},
                        icon: {Image(systemName:"yieldsign.fill")
                        }
                    )
                }
                
                
                Text("Problematicas").font(.largeTitle)
                
                HStack{
                    VStack{
                        NavigationLink{
                            //ventana()
                        } label:{
                            Image("salud")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 100, height: 200)
                        }
                        Text("Salud")
                            .offset(x: 1, y:-30)
                        
                    }
                    VStack{
                        NavigationLink{
                            //ventana()
                        } label:{
                            Image("salud")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 100, height: 200)
                        }
                        Text("Salud")
                            .offset(x: 1, y:-30)
                    }
                    VStack{
                        NavigationLink{
                            //ventana()
                        } label:{
                            Image("salud")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 100, height: 200)
                        }
                        Text("Salud")
                            .offset(x: 1, y:-30)
                        
                    }
                }
                HStack{
                    VStack{
                        NavigationLink{
                            //ventana()
                        } label:{
                            Image("salud")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 100, height: 200)
                        }
                        Text("Salud")
                            .offset(x: 1, y:-30)
                        
                    }
                    VStack{
                        NavigationLink{
                            //ventana()
                        } label:{
                            Image("salud")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 100, height: 200)
                        }
                        Text("Salud")
                            .offset(x: 1, y:-30)
                        
                    }
                    VStack{
                        NavigationLink{
                            //ventana()
                        } label:{
                            Image("salud")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 100, height: 200)
                        }
                        Text("Salud")
                            .offset(x: 1, y:-30)
                        
                    }
                }
                NavigationLink{
                    ventana3()
                } label:{
                    Text("Siguiente")
                        .foregroundColor(.black)
                        .frame(width: 250, height: 60)
                        .background(.yellow)
                        .cornerRadius(100)
                }
                
            }
            
        }
    }
}
#Preview {
    ventana2()
}






