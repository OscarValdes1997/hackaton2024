//
//  ComputerNerdysApp.swift
//  ComputerNerdys
//
//  Created by CEDAM02 on 07/03/24.
//

import SwiftUI

@main
struct ComputerNerdysApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
