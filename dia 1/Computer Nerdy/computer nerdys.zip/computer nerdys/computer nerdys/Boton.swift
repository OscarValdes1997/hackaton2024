//
//  Boton.swift
//  computer nerdys
//
//  Created by CEDAM03 on 07/03/24.
//

import SwiftUI

struct Boton: View {
    var body: some View {
        ZStack
        {
            Text("Reporte enviado")
                .font(.custom("Courier", size: 30))
                .padding(.top,-200)
            
        }
    }
}

#Preview {
    Boton()
}
