//
//  HackatonApp.swift
//  Hackaton
//
//  Created by CEDAM01 on 07/03/24.
//

import SwiftUI

@main
struct HackatonApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
