//
//  ItemLista.swift
//  Hackaton
//
//  Created by CEDAM01 on 07/03/24.
//

import Foundation
import SwiftUI

struct ItemList {
    var id: Int
    var ruta: String
    var label: String
}
