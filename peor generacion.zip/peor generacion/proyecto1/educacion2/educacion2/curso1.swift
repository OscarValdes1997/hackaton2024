//
//  curso1.swift
//  educacion2
//
//  Created by CEDAM16 on 07/03/24.
//

import SwiftUI

struct curso1: View 
{
    var body: some View 
    {
        VStack
        {
            Image("arq")
            VStack
            {
                ZStack
                {
                    Rectangle()
                        .foregroundColor(.black)
                    VStack
                    {
                        Text("Dibujo Aquitectonico")
                            .font(.headline)
                            .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                            .foregroundStyle(.white)
                    
                        
                    }
                }
                
            }
            
        }
    }
}

#Preview {
    curso1()
}
