//
//  perfil.swift
//  educacion2
//
//  Created by CEDAM16 on 07/03/24.
//

import SwiftUI

struct perfil: View 
{
    var body: some View 
    {
        ZStack
        {
            VStack
            {
                Rectangle()
                    .frame(width:270, height: 600)
                    .cornerRadius(25)
                    .foregroundColor(.cyan)

            }
            VStack
            {
                Image("rostro")
                    .resizable()
                    .scaledToFill()
                    .frame(width: 150, height: 150)
                    .clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
                    .padding(.top)
                VStack
                {
                    
                    VStack
                    {
                        ZStack
                        {
                            
                            Rectangle()
                                .frame(width:200, height: 50)
                                .cornerRadius(25)
                                .foregroundColor(.white)
                            VStack
                            {
                                Text("Nombre:")
                                    .font(.system(size: 13,weight: .bold))
                                Text("Sofia Guitierres")
                                    .font(.system(size: 20,weight: .light))
                            }
                        }
                    }

                    VStack
                    {
                        ZStack
                        {
                            
                            Rectangle()
                                .frame(width:200, height: 50)
                                .cornerRadius(25)
                                .foregroundColor(.white)
                            VStack(spacing:5)
                            {
                                Text("Edad:")
                                    .font(.system(size: 13,weight: .bold))
                                Text("27")
                                    .font(.system(size: 20,weight: .light))
                            }
                        }
                    }
                    VStack
                    {
                        ZStack
                        {
                            
                            Rectangle()
                                .frame(width:200, height: 200)
                                .cornerRadius(25)
                                .foregroundColor(.white)
                                .padding()
                            VStack(spacing:15)
                            {
                                Text("Cursos en curso:")
                                    .font(.system(size: 20,weight: .bold))
                                
                                Text("Probabilidad")
                                Text("Redes de Computadoras")
                                Text("Analisis Real")
                                    
                                                                }
                        }
                        .padding()
                    }
                    
            
                }
       
            }
            
        }
    }
}

#Preview {
    perfil()
}
