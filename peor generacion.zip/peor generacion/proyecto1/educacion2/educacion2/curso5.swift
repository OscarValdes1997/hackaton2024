//
//  curso5.swift
//  educacion2
//
//  Created by CEDAM16 on 07/03/24.
//

import SwiftUI

struct curso5: View {
    var body: some View 
    {
        VStack
        {
            Image("biologia")
            VStack
            {
                ZStack
                {
                    Rectangle()
                        .foregroundColor(.black)
                    VStack
                    {
                        Text("Biologia I")
                            .font(.headline)
                            .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                            .foregroundStyle(.white)
                    
                        
                    }
                }
                
            }
            
        }
    }
}

#Preview {
    curso5()
}
