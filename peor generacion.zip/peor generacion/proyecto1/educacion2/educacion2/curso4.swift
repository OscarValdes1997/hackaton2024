//
//  curso4.swift
//  educacion2
//
//  Created by CEDAM16 on 07/03/24.
//

import SwiftUI

struct curso4: View {
    var body: some View 
    {
        VStack
        {
            Image("diseño")
            VStack
            {
                ZStack
                {
                    Rectangle()
                        .foregroundColor(.black)
                    VStack
                    {
                        Text("Diseño de Autos")
                            .font(.headline)
                            .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                            .foregroundStyle(.white)
                    
                        
                    }
                }
                
            }
            
        }
    }
}

#Preview {
    curso4()
}
