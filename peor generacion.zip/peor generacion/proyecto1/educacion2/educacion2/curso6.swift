//
//  curso6.swift
//  educacion2
//
//  Created by CEDAM16 on 07/03/24.
//

import SwiftUI

struct curso6: View {
    var body: some View 
    {
        VStack
        {
            Image("quimica")
            VStack
            {
                ZStack
                {
                    Rectangle()
                        .foregroundColor(.black)
                    VStack
                    {
                        Text("Quimica Organica")
                            .font(.headline)
                            .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                            .foregroundStyle(.white)
                    
                        
                    }
                }
                
            }
            
        }
    }
}

#Preview {
    curso6()
}
