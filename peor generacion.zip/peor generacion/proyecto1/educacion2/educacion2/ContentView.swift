//
//  ContentView.swift
//  educacion2
//
//  Created by CEDAM16 on 07/03/24.
//

import SwiftUI

struct ContentView: View
{
    var body: some View
    {
        NavigationStack
        {
                        
            ZStack
            {
                VStack
                {
                    
                    HStack
                    {
                        NavigationLink
                        {
                            ventana1()
                        }label:{
                            Text("Ingresar")
                                .foregroundStyle(Color.white)
                                .frame(width: 150, height: 50)
                                .background(.cyan)
                                .cornerRadius(25)
                                .position(x: 100.0, y:35.0)
                                
                            
                        }
                        NavigationLink
                        {
                            ventana2()
                        }label:{
                            Text("Registro")
                                .foregroundStyle(Color.white)
                            
                                .frame(width: 150, height: 50)
                                .background(.cyan)
                                .cornerRadius(25)
                                .position(x: 95.0, y:35.0)
                                
                            
                        }
                    }
                    

                    
                }
                
                Circle()
                    .padding()
                    .foregroundColor(.gray)
                    .frame(width: 400)
                ZStack
                {
                    
                    Text("Esta app es para conseguir cursos gratuitos sobre algo.")
                        .fontWeight(.medium)
                        .padding()
                }
                    
                    
                
                }
                                
                
        }
            
    }
}

#Preview {
    ContentView()
}
