//
//  curso2.swift
//  educacion2
//
//  Created by CEDAM16 on 07/03/24.
//

import SwiftUI

struct curso2: View {
    var body: some View 
    {
        VStack
        {
            Image("redes")
            VStack
            {
                ZStack
                {
                    Rectangle()
                        .foregroundColor(.black)
                    VStack
                    {
                        Text("Redes Neuronales")
                            .font(.headline)
                            .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                            .foregroundStyle(.white)
                    
                        
                    }
                }
                
            }
            
        }
    }
}

#Preview {
    curso2()
}
