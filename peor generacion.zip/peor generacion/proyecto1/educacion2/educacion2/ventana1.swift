//
//  ventana1.swift
//  educacion2
//
//  Created by CEDAM16 on 07/03/24.
//

import SwiftUI

struct ventana1: View
{
    var body: some View
    {
        NavigationStack
        {
            
            
            VStack
            //Image("oscuro")
            {
                HStack
                {
                    VStack
                    {
                        Image("rostro")
                            .resizable()
                            .scaledToFill()
                            .frame(width: 100, height: 100)
                            .clipped()
                            .clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
                        NavigationLink
                          {
                              perfil()
                          }label:{
                              Text("Perfil")
                                  .frame(width: 50,height: 50)
                          }
                    }
                }
            }
            Text("Curso Recomendados")
                .font(.callout)
            ScrollView(.horizontal)
            {
                HStack
                {
                    VStack
                    {
                        NavigationLink{
                            curso1()
                        }label:{
                            Image("arq")
                                .resizable()
                                .scaledToFill()
                                .frame(width: 100, height: 100)
                                .cornerRadius(20)
                                .clipped()
                                .clipShape(Rectangle())
                           
                            
                        }
                        Text("Dibujo Arquitectonico")
                        
                    }
                    VStack
                    {
                        NavigationLink{
                            curso2()
                        }label:{
                            Image("redes")
                                .resizable()
                                .scaledToFill()
                                .frame(width: 100, height: 100)
                                .cornerRadius(20)
                                .clipped()
                                .clipShape(Rectangle())
                            
                        }
                        Text("Redes Neuronales")
                    }
                    VStack
                    {
                        NavigationLink{
                            curso3()
                        }label:{
                            Image("analisis")
                                .resizable()
                                .scaledToFill()
                                .frame(width: 100, height: 100)
                                .cornerRadius(20)
                                .clipped()
                                .clipShape(Rectangle())
                            
                        }
                        Text("Analisis Real")
                        
                    }
                    VStack
                    {
                        NavigationLink{
                            curso4()
                        }label:{
                            Image("diseño")
                                .resizable()
                                .scaledToFill()
                                .frame(width: 100, height: 100)
                                .cornerRadius(20)
                                .clipped()
                                .clipShape(Rectangle())
                            
                        }
                        Text("Diseño")
                        
                    }
                    VStack
                    {
                        NavigationLink{
                            curso5()
                        }label:{
                            Image("biologia")
                                .resizable()
                                .scaledToFill()
                                .frame(width: 100, height: 100)
                                .cornerRadius(20)
                                .clipped()
                                .clipShape(Rectangle())
                            
                        }
                        Text("Biologia I")
                        
                    }
                    VStack
                    {
                        NavigationLink{
                            curso6()
                        }label:{
                            Image("quimica")
                                .resizable()
                                .scaledToFill()
                                .frame(width: 100, height: 100)
                                .cornerRadius(20)
                                .clipped()
                                .clipShape(Rectangle())
                            
                        }
                        Text("Quimica Organica")
                    }
                    
                }
            }
            .padding(.top,30)
            
        
            
            ScrollView(.vertical)
            {
                VStack(spacing: 20){
                    HStack
                    {
                        VStack
                        {
                            NavigationLink{
                                curso6()
                            }label:{
                                Image("reposteria")
                                    .resizable()
                                    .scaledToFill()
                                    .frame(width: 100, height: 100)
                                    .cornerRadius(20)
                                    .clipped()
                                    .clipShape(Rectangle())
                                
                            }
                            
                        }
                        VStack
                        {
                            Text("Reposteria ")
                                .font(.system(size: 25,weight: .light))
                            Text("descripcion del curso")
                                .padding()
                        }
                    }
                    HStack
                    {
                        VStack
                        {
                            NavigationLink{
                                curso6()
                            }label:{
                                Image("autocad")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 100, height: 100)
                                    .cornerRadius(20)
                                    .clipped()
                                    .clipShape(Rectangle())
                                
                            }
                            
                        }
                        VStack
                        {
                            Text("Auto-Cad ")
                                .font(.system(size: 25,weight: .light))
                            Text("descripcion del curso")
                                .padding()
                        }
                    }
                    HStack
                    {
                        VStack
                        {
                            NavigationLink{
                                curso6()
                            }label:{
                                Image("origami")
                                    .resizable()
                                    .scaledToFill()
                                    .frame(width: 100, height: 100)
                                    .cornerRadius(20)
                                    .clipped()
                                    .clipShape(Rectangle())
                                
                            }
                            
                        }
                        VStack
                        {
                            Text("Origami ")
                                .font(.system(size: 25,weight: .light))
                            Text("descripcion del curso")
                                .padding()
                        }
                    }
                    HStack
                    {
                        VStack
                        {
                            NavigationLink{
                                curso6()
                            }label:{
                                Image("3d")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 100, height: 100)
                                    .cornerRadius(20)
                                    .clipped()
                                    .clipShape(Rectangle())
                                
                            }
                            
                        }
                        VStack
                        {
                            Text("Modelado 3D ")
                                .font(.system(size: 25,weight: .light))
                            Text("descripcion del curso")
                                .padding()
                        }
                    }
                    HStack
                    {
                        VStack
                        {
                            NavigationLink{
                                curso6()
                            }label:{
                                Image("rostro")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 100, height: 100)
                                    .cornerRadius(20)
                                    .clipped()
                                    .clipShape(Rectangle())
                                
                            }
                            
                        }
                        VStack
                        {
                            Text("Curso25 ")
                                .font(.system(size: 25,weight: .light))
                            Text("descripcion del curso")
                                .padding()
                        }
                    }
                    

                }
            }
            .padding(.top,50)

            
        }
        
    }
}

#Preview {
    ventana1()
}

