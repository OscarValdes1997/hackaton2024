//
//  Bienvenida.swift
//  VanIta
//
//  Created by CEDAM17 on 07/03/24.
//

import SwiftUI

struct Bienvenida: View {
    var body: some View {
        VStack {
            Image(systemName: "globe")
                .imageScale(.large)
                .foregroundStyle(.tint)
            Text("Hello, world!")
            
            Text("pantalla del Curso")
        }
        .padding()
    }
}

#Preview {
    Bienvenida()
}
