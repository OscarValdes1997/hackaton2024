//
//  ListaDeContactosView.swift
//  AgendaAPI
//
//  Created by Oscar on 14/02/24.
//

import SwiftUI


class ContactosViewModel1: ObservableObject {
    @Published var contactos: [Contacto] = []
    
    func obtenerContactos() {
        guard let url = URL(string: "https://jbw6dv55-5000.usw3.devtunnels.ms/contactos") else { return }
        
        URLSession.shared.dataTask(with: url) { data, _, error in
            if let data = data {
                let decoder = JSONDecoder()
                do {
                    let contactos = try decoder.decode([Contacto].self, from: data)
                    DispatchQueue.main.async {
                        self.contactos = contactos
                    }
                } catch {
                    print("Error al decodificar datos:", error)
                }
            }
        }.resume()
    }
    
    func agregarContacto(Contacto: Contacto, onSuccess: @escaping () -> Void, onError: @escaping () -> Void) {
        guard let url = URL(string: "https://jbw6dv55-5000.usw3.devtunnels.ms/contactos") else { return }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let encoder = JSONEncoder()
        guard let jsonData = try? encoder.encode(Contacto) else {
            print("Error al codificar el nuevo contacto")
            onError()
            return
        }
        
        request.httpBody = jsonData
        
        URLSession.shared.dataTask(with: request) { data, response, error in
            if let response = response as? HTTPURLResponse {
                if response.statusCode == 201 {
                    DispatchQueue.main.async {
                        onSuccess()
                    }
                } else {
                    DispatchQueue.main.async {
                        onError()
                    }
                }
            }
        }.resume()
    }
}

struct AgregarNuevoContactoView: View {
    @State private var nombre = ""
    @State private var telefono = ""
    @State private var direccion = ""
    
    @ObservedObject var viewModel: ContactosViewModel1
    @State private var showAlert = false
    @State private var alertMessage = ""
    
    var body: some View {
        Form {
            TextField("Nombre", text: $nombre)
            TextField("Teléfono", text: $telefono)
            TextField("Dirección", text: $direccion)
            
            Button("Guardar") {
                let Contacto = Contacto(id: nil, nombre: nombre, telefono: telefono, direccion: direccion)
                viewModel.agregarContacto(Contacto: Contacto, onSuccess: {
                    showAlert = true
                    alertMessage = "Contacto agregado exitosamente"
                }, onError: {
                    showAlert = true
                    alertMessage = "Error al agregar el contacto"
                })
            }
        }
        .navigationTitle("Agregar Contacto")
        .alert(isPresented: $showAlert) {
            Alert(title: Text("Mensaje"), message: Text(alertMessage), dismissButton: .default(Text("OK")))
        }
    }
}

struct ListaDeContactosView: View {
    @StateObject var viewModel = ContactosViewModel1()
    
    var body: some View {
        NavigationView {
            List(viewModel.contactos, id: \.id) { contacto in
                VStack(alignment: .leading) {
                    Text(contacto.nombre)
                    Text(contacto.telefono)
                    Text(contacto.direccion)
                }
            }
            .navigationTitle("Contactos")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    NavigationLink(destination: AgregarNuevoContactoView(viewModel: viewModel)) {
                        Image(systemName: "plus")
                    }
                }
            }
        }
        .onAppear {
            viewModel.obtenerContactos()
        }
    }
}

#Preview {
    ListaDeContactosView()
}
