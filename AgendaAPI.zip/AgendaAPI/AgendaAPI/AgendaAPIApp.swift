//
//  AgendaAPIApp.swift
//  AgendaAPI
//
//  Created by Oscar on 12/02/24.
//

import SwiftUI

@main
struct AgendaAPIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
