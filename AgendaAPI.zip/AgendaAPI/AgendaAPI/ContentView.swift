//
//  ContentView.swift
//  AgendaAPI
//
//  Created by Oscar on 12/02/24.
//

import SwiftUI

struct Contacto: Codable {
    let id: Int?
    let nombre: String
    let telefono: String
    let direccion: String
}



struct ContentView: View {
    
    var body: some View {
        ListaDeContactosView()
    }
}

#Preview {
    ContentView()
}
