//
//  ActualizarContactoView.swift
//  AgendaAPI
//
//  Created by Oscar on 14/02/24.
//

import SwiftUI

struct ActualizarContactoView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    ActualizarContactoView()
}
